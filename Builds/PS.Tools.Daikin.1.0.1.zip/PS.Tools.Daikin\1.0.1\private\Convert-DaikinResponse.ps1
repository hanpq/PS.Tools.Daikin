﻿<#PSScriptInfo
    .VERSION 1.0.0.0
    .GUID 97f6f35a-bf9b-4f28-84fe-9181732a2d24
    .FILENAME Convert-DaikinResponse.ps1
    .AUTHOR Hannes Palmquist
    .AUTHOREMAIL hannes.palmquist@outlook.com
    .CREATEDDATE 2020-10-03
    .COMPANYNAME Personal
    .COPYRIGHT (c) 2020, Hannes Palmquist, All Rights Reserved
#>
function Convert-DaikinResponse {
    <#
    .DESCRIPTION
        asd
    .PARAMETER Name
        Description
    .EXAMPLE
        Convert-DaikinResponse
        Description of example
    #>

    [CmdletBinding()] # Enabled advanced function support
    param(
        $String,
        [switch]$Raw
    )

    BEGIN {        
        $Translation = @{
            'id'       = 'Identity'
            'pow'      = 'PowerOn'
            'type'     = 'DeviceType'
            'reg'      = 'Region'
            'ver'      = 'Version'
            'rev'      = 'Revision'
            'err'      = 'Error'
            'pw'       = 'Password'
            'led'      = 'LED_Enabled'
            'grp_name' = 'GroupName'
            'location' = 'Location'
            'stemp'    = 'TargetTemp'
            'htemp'    = 'InsideTemp'
            'otemp'    = 'OutsideTemp'
            'hhum'     = 'InsideHumidity'
            'mode'     = 'Mode'
            'f_rate'   = 'FanSpeed'
            'f_dir'    = 'FanDirection'
            'shum'     = 'TargetHumidity'
            'dh1'      = 'Mem_AUTO_TargetHumidity'
            'dh2'      = 'Mem_DEHUMDIFICATOR_TargetHumidity'
            'dh3'      = 'Mem_COLD_TargetHumidity'
            'dh4'      = 'Mem_HEAT_TargetHumidity'
            'dh5'      = 'Mem_FAN_TargetHumidity'
            'dh7'      = 'Mem_AUTO_TargetHumidity'
            'dt1'      = 'Mem_AUTO_TargetTemp'
            'dt2'      = 'Mem_DEHUMDIFICATOR_TargetTemp'
            'dt3'      = 'Mem_COLD_TargetTemp'
            'dt4'      = 'Mem_HEAT_TargetTemp'
            'dt5'      = 'Mem_FAN_TargetTemp'
            'dt7'      = 'Mem_AUTO_TargetTemp'
        }
    }

    PROCESS {
        $Hash = [ordered]@{}
        $String.Split(',') | foreach-object {
            $Property = $PSItem.Split('=')[0]
            $Value = $PSItem.Split('=')[1]

            if (-not $Raw) {
                # Translate keys
                if ($Translation.ContainsKey($Property)) {
                    $Property = $Translation[$Property]    
                }
            
                switch ($Property) {
                    { @('PowerOn') -contains $PSItem } {
                        $Value = [bool][int]$Value
                    }
                    'Mode' {
                        switch ($Value) {
                            { 0, 1, 7 -contains $PSItem } { $Value = 'AUTO' }
                            2 { $Value = 'DRY' }
                            3 { $Value = 'COLD' }
                            4 { $Value = 'HEAT' }
                            6 { $Value = 'FAN' }
                        }
                    }
                    'FanSpeed' {
                        switch ($Value) {
                            'A' { $Value = 'AUTO' }
                            'B' { $Value = 'SILENT' }
                            '3' { $Value = 'Level_1' }
                            '4' { $Value = 'Level_2' }
                            '5' { $Value = 'Level_3' }
                            '6' { $Value = 'Level_4' }
                            '7' { $Value = 'Level_5' }
                        }
                    }
                    'FanDirection' {
                        switch ($Value) {
                            '0' { $Value = 'Stopped' }
                            '1' { $Value = 'VerticalSwing' }
                            '2' { $Value = 'HorizontalSwing' }
                            '3' { $Value = 'BothSwing' }
                        }
                    }
                }
            }            
            $Hash.$Property = $Value
        }
        $Hash
    }
}
#endregion
# SIG # Begin signature block
# MIIUvwYJKoZIhvcNAQcCoIIUsDCCFKwCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUcxDFBl+A35sa4bSDfNayNjad
# vY6gghBHMIIDBDCCAeygAwIBAgIQXaH43Bl75ZhMB4kpXyZ2qjANBgkqhkiG9w0B
# AQUFADAaMRgwFgYDVQQDDA9IYW5uZXNQYWxtcXVpc3QwHhcNMjAxMDIyMDczMDU3
# WhcNMjUxMDIyMDc0MDU3WjAaMRgwFgYDVQQDDA9IYW5uZXNQYWxtcXVpc3QwggEi
# MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQClDvznsRz3hBOHS8rZ5ZlNB/ac
# GrKUQyoH0Pk6JONmIBeQPLwurne3ulSwb+6cbwwgp87eSnGoq4YbAFfqTbwytKLn
# YmIoHGiCrwxZb5YU6ijOrW6Sywa+H+/uKsZqJfXFRn1vGnC5tZwa5rSngLaow1qV
# tvyRQGRGNpI02hUwtChneJJmwk2B8dtY1ECH6Ob9LFlWETcETy5T5RKSS1sRWATk
# K9EQsZ65AHbGKGkpDv8y/+g7hg3KKU+m8f3ahMscMB5tvyPr3tmPsMFpFW3kCfz0
# FRBOizw+HYZX6nnSQ+aTMyXNuIXCv4Cp+1rSGdLwnRqbY5iUQca/8VZF45iZAgMB
# AAGjRjBEMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNV
# HQ4EFgQU1v0fOEkDehQn807IU73u51uJNQ0wDQYJKoZIhvcNAQEFBQADggEBABwb
# e2Ghq71GqGwx2/GoXa/Nv4XhW2O0TT5vgn6RysorCPUKTnCYKn6wGWZpdMbndXXU
# d6ziS+EW0+cxr7ZdFCTsfBroArJ3BIFjPoRt3hYqZR154nLNRnFPKhzgpusqDpSx
# BnMd7wRrKsW3GdSOfeGyiR7/9Ye2uiFp6y4wpU/qcU+LuxS2fbyUB2XGVPPWXxxF
# bjtgrlit7czi7WTjfe4YVgxyyrJ9IsMz8fPlLPy9Pfbfacpo6/p6qINhsmv+/V1o
# 7U2XIlg2w1ABj20sZ3mn+TKS2mmxNkIdCb38rUK8UJwqHX9byi9M1MrJYFJwRNwH
# 37l4hxzeVXIaiA6vWJAwggZqMIIFUqADAgECAhADAZoCOv9YsWvW1ermF/BmMA0G
# CSqGSIb3DQEBBQUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IEFzc3VyZWQgSUQgQ0EtMTAeFw0xNDEwMjIwMDAwMDBaFw0yNDEwMjIwMDAwMDBa
# MEcxCzAJBgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDElMCMGA1UEAxMcRGln
# aUNlcnQgVGltZXN0YW1wIFJlc3BvbmRlcjCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBAKNkXfx8s+CCNeDg9sYq5kl1O8xu4FOpnx9kWeZ8a39rjJ1V+JLj
# ntVaY1sCSVDZg85vZu7dy4XpX6X51Id0iEQ7Gcnl9ZGfxhQ5rCTqqEsskYnMXij0
# ZLZQt/USs3OWCmejvmGfrvP9Enh1DqZbFP1FI46GRFV9GIYFjFWHeUhG98oOjafe
# Tl/iqLYtWQJhiGFyGGi5uHzu5uc0LzF3gTAfuzYBje8n4/ea8EwxZI3j6/oZh6h+
# z+yMDDZbesF6uHjHyQYuRhDIjegEYNu8c3T6Ttj+qkDxss5wRoPp2kChWTrZFQlX
# mVYwk/PJYczQCMxr7GJCkawCwO+k8IkRj3cCAwEAAaOCAzUwggMxMA4GA1UdDwEB
# /wQEAwIHgDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIIB
# vwYDVR0gBIIBtjCCAbIwggGhBglghkgBhv1sBwEwggGSMCgGCCsGAQUFBwIBFhxo
# dHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BTMIIBZAYIKwYBBQUHAgIwggFWHoIB
# UgBBAG4AeQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAgAEMAZQByAHQAaQBmAGkA
# YwBhAHQAZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAgAGEAYwBjAGUAcAB0AGEA
# bgBjAGUAIABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBlAHIAdAAgAEMAUAAvAEMA
# UABTACAAYQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBuAGcAIABQAGEAcgB0AHkA
# IABBAGcAcgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAgAGwAaQBtAGkAdAAgAGwA
# aQBhAGIAaQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAgAGkAbgBjAG8AcgBwAG8A
# cgBhAHQAZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIAByAGUAZgBlAHIAZQBuAGMA
# ZQAuMAsGCWCGSAGG/WwDFTAfBgNVHSMEGDAWgBQVABIrE5iymQftHt+ivlcNK2cC
# zTAdBgNVHQ4EFgQUYVpNJLZJMp1KKnkag0v0HonByn0wfQYDVR0fBHYwdDA4oDag
# NIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEQ0Et
# MS5jcmwwOKA2oDSGMmh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFz
# c3VyZWRJRENBLTEuY3JsMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURDQS0xLmNydDANBgkqhkiG
# 9w0BAQUFAAOCAQEAnSV+GzNNsiaBXJuGziMgD4CH5Yj//7HUaiwx7ToXGXEXzakb
# vFoWOQCd42yE5FpA+94GAYw3+puxnSR+/iCkV61bt5qwYCbqaVchXTQvH3Gwg5QZ
# BWs1kBCge5fH9j/n4hFBpr1i2fAnPTgdKG86Ugnw7HBi02JLsOBzppLA044x2C/j
# bRcTBu7kA7YUq/OPQ6dxnSHdFMoVXZJB2vkPgdGZdA0mxA5/G7X1oPHGdwYoFenY
# k+VVFvC7Cqsc21xIJ2bIo4sKHOWV2q7ELlmgYd3a822iYemKC23sEhi991VUQAOS
# K2vCUcIKSK+w1G7g9BQKOhvjjz3Kr2qNe9zYRDCCBs0wggW1oAMCAQICEAb9+QOW
# A63qAArrPye7uhswDQYJKoZIhvcNAQEFBQAwZTELMAkGA1UEBhMCVVMxFTATBgNV
# BAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIG
# A1UEAxMbRGlnaUNlcnQgQXNzdXJlZCBJRCBSb290IENBMB4XDTA2MTExMDAwMDAw
# MFoXDTIxMTExMDAwMDAwMFowYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lD
# ZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGln
# aUNlcnQgQXNzdXJlZCBJRCBDQS0xMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB
# CgKCAQEA6IItmfnKwkKVpYBzQHDSnlZUXKnE0kEGj8kz/E1FkVyBn+0snPgWWd+e
# tSQVwpi5tHdJ3InECtqvy15r7a2wcTHrzzpADEZNk+yLejYIA6sMNP4YSYL+x8cx
# SIB8HqIPkg5QycaH6zY/2DDD/6b3+6LNb3Mj/qxWBZDwMiEWicZwiPkFl32jx0Pd
# Aug7Pe2xQaPtP77blUjE7h6z8rwMK5nQxl0SQoHhg26Ccz8mSxSQrllmCsSNvtLO
# Bq6thG9IhJtPQLnxTPKvmPv2zkBdXPao8S+v7Iki8msYZbHBc63X8djPHgp0XEK4
# aH631XcKJ1Z8D2KkPzIUYJX9BwSiCQIDAQABo4IDejCCA3YwDgYDVR0PAQH/BAQD
# AgGGMDsGA1UdJQQ0MDIGCCsGAQUFBwMBBggrBgEFBQcDAgYIKwYBBQUHAwMGCCsG
# AQUFBwMEBggrBgEFBQcDCDCCAdIGA1UdIASCAckwggHFMIIBtAYKYIZIAYb9bAAB
# BDCCAaQwOgYIKwYBBQUHAgEWLmh0dHA6Ly93d3cuZGlnaWNlcnQuY29tL3NzbC1j
# cHMtcmVwb3NpdG9yeS5odG0wggFkBggrBgEFBQcCAjCCAVYeggFSAEEAbgB5ACAA
# dQBzAGUAIABvAGYAIAB0AGgAaQBzACAAQwBlAHIAdABpAGYAaQBjAGEAdABlACAA
# YwBvAG4AcwB0AGkAdAB1AHQAZQBzACAAYQBjAGMAZQBwAHQAYQBuAGMAZQAgAG8A
# ZgAgAHQAaABlACAARABpAGcAaQBDAGUAcgB0ACAAQwBQAC8AQwBQAFMAIABhAG4A
# ZAAgAHQAaABlACAAUgBlAGwAeQBpAG4AZwAgAFAAYQByAHQAeQAgAEEAZwByAGUA
# ZQBtAGUAbgB0ACAAdwBoAGkAYwBoACAAbABpAG0AaQB0ACAAbABpAGEAYgBpAGwA
# aQB0AHkAIABhAG4AZAAgAGEAcgBlACAAaQBuAGMAbwByAHAAbwByAGEAdABlAGQA
# IABoAGUAcgBlAGkAbgAgAGIAeQAgAHIAZQBmAGUAcgBlAG4AYwBlAC4wCwYJYIZI
# AYb9bAMVMBIGA1UdEwEB/wQIMAYBAf8CAQAweQYIKwYBBQUHAQEEbTBrMCQGCCsG
# AQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0
# dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RD
# QS5jcnQwgYEGA1UdHwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmw0
# LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwHQYDVR0O
# BBYEFBUAEisTmLKZB+0e36K+Vw0rZwLNMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1R
# i6enIZ3zbcgPMA0GCSqGSIb3DQEBBQUAA4IBAQBGUD7Jtygkpzgdtlspr1LPUukx
# R6tWXHvVDQtBs+/sdR90OPKyXGGinJXDUOSCuSPRujqGcq04eKx1XRcXNHJHhZRW
# 0eu7NoR3zCSl8wQZVann4+erYs37iy2QwsDStZS9Xk+xBdIOPRqpFFumhjFiqKgz
# 5Js5p8T1zh14dpQlc+Qqq8+cdkvtX8JLFuRLcEwAiR78xXm8TBJX/l/hHrwCXaj+
# +wc4Tw3GXZG5D2dFzdaD7eeSDY2xaYxP+1ngIw/Sqq4AfO6cQg7PkdcntxbuD8O9
# fAqg7iwIVYUiuOsYGk38KiGtSTGDR5V3cdyxG0tLHBCcdxTBnU8vWpUIKRAmMYID
# 4jCCA94CAQEwLjAaMRgwFgYDVQQDDA9IYW5uZXNQYWxtcXVpc3QCEF2h+NwZe+WY
# TAeJKV8mdqowCQYFKw4DAhoFAKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAw
# GQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisG
# AQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFFA8X/NVdeEZThoEy6oouxfnKUYTMA0G
# CSqGSIb3DQEBAQUABIIBAC8ko/lDgUXCVX/sJaOOgLpBtyJgTx3zEG03OvCxq0R3
# JUWd80/M3lGLqZbF+/AkIwurrowmnawBPmW5zIiZHoLM0ui6JIR6zzeK1t665eIh
# fhzjH7mbjsvSrorHVtoL+Hxvt9U/zYcRxN3MbGbuox7WvIExMiRIX1o9+YTnwY0c
# zVcUKuvY60ALb6KHRzUTuVAc5/lNxaTxpTpp0xBQTxkIo7nAP86WUssgRK0g+RSZ
# j+IU6WQ33jYocpQynF6fWIPAtoV11AhW+wLl9T8heaZNlIOlH6K9QnZAnONslHWp
# wvUSThHuMR7qafaZ/nnScxi0CzbJ6jRVsPds97+Fv1ahggIPMIICCwYJKoZIhvcN
# AQkGMYIB/DCCAfgCAQEwdjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNl
# cnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdp
# Q2VydCBBc3N1cmVkIElEIENBLTECEAMBmgI6/1ixa9bV6uYX8GYwCQYFKw4DAhoF
# AKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTIw
# MTAzMDIxNTE1NFowIwYJKoZIhvcNAQkEMRYEFNuS7H9NBJ6pUTACWLWa5xK/qjKK
# MA0GCSqGSIb3DQEBAQUABIIBAE9qxwc++qW7HrJ1KDEDPzvcXvArOBU7HkXj1QjP
# ILnry+hYbHzuNWujmo4pQ1NdSTQdxCfWsbTPN5gSH6JkynbI6zzr1j3u2LqPTRkP
# CoBlq4x6qwZtngFJJ+XO+guQx+eT/azrTw3O1XE3SOWX3QYbeDNQvj5ZzTeh06eq
# 6jPDHOTcS3Lq1MfGc9GRB4V804SbZWjRQlWqfFGw7Q5hCeuGqxLeGp6N+OwlieWV
# Qcbmn8bxBL6Sw4AYqRPpQuoEYTCOKYQtWGVBq2e76BAYgw+NpFOqNabYCm1hLONv
# rL/0Dv+vkK73AvML1S2ugv4304voj30A31wakFreoLmXX9A=
# SIG # End signature block
