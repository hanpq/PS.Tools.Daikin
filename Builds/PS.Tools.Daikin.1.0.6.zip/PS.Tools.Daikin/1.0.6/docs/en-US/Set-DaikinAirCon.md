---
external help file: PS.Tools.Daikin-help.xml
Module Name: PS.Tools.Daikin
online version:
schema: 2.0.0
---

# Set-DaikinAirCon

## SYNOPSIS

## SYNTAX

```
Set-DaikinAirCon [[-HostName] <Object>] [[-PowerOn] <Boolean>] [[-Temp] <Int32>] [[-Mode] <Object>]
 [[-FanSpeed] <Object>] [[-FanDirection] <Object>] [<CommonParameters>]
```

## DESCRIPTION
asd

## EXAMPLES

### EXAMPLE 1
```
Set-DaikinAirCon
```

Description of example

## PARAMETERS

### -HostName
{{ Fill HostName Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PowerOn
{{ Fill PowerOn Description }}

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 2
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -Temp
{{ Fill Temp Description }}

```yaml
Type: Int32
Parameter Sets: (All)
Aliases:

Required: False
Position: 3
Default value: 0
Accept pipeline input: False
Accept wildcard characters: False
```

### -Mode
{{ Fill Mode Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 4
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -FanSpeed
{{ Fill FanSpeed Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -FanDirection
{{ Fill FanDirection Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 6
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
